package text;  // DO NOT CHANGE THIS OR YOU WILL GET ZERO

import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * SOFTENG 254 Assignment 1 submission template
 *
 * Author: (name, username)
 **/

public class TestFlushLeft {// DO NOT CHANGE THE CLASS NAME OR YOU WILL GET ZERO

    // Your tests here.
    @Test
    public void demo() {
        fail("I am a demo test case. I can be deleted");
    }
}
