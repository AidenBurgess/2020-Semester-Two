package se325.assignment01.concert.common.types;

public enum BookingStatus {
    Booked, Unbooked, Any
}
